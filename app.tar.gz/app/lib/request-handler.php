<?php

require_once('functions.php');

request_handler();

?>