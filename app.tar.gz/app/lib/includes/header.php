<?php notification(); ?>

<header class="masthead">

	<div class="wrapper">
	
		<a class="home" href="">Memcached Monitor</a>
		
		<div class="clear"></div>
	
	</div><!-- End wrapper -->
	
</header><!-- End header -->